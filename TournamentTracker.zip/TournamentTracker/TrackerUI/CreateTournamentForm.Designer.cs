﻿namespace TrackerUI
{
    partial class CreateTournamentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            createHeaderTournament = new Label();
            TournamentLabel = new Label();
            tournamentNameValue = new TextBox();
            teamOneScoreValue = new TextBox();
            entryFeeLabel = new Label();
            entryFeeValue = new TextBox();
            selectTeamDropdown = new ComboBox();
            selectTeamLabel = new Label();
            addTeamLink = new LinkLabel();
            addTeamButton = new Button();
            createPrizeButton = new Button();
            tournamentPlayersListbox = new ListBox();
            label1 = new Label();
            button1 = new Button();
            prizesDeleteBUtton = new Button();
            prizesLabel = new Label();
            prizesListBox = new ListBox();
            createTournamentButton = new Button();
            SuspendLayout();
            // 
            // createHeaderTournament
            // 
            createHeaderTournament.AutoSize = true;
            createHeaderTournament.Font = new Font("Segoe UI Light", 28.2F, FontStyle.Regular, GraphicsUnit.Point);
            createHeaderTournament.ForeColor = SystemColors.MenuHighlight;
            createHeaderTournament.Location = new Point(12, 9);
            createHeaderTournament.Name = "createHeaderTournament";
            createHeaderTournament.Size = new Size(413, 62);
            createHeaderTournament.TabIndex = 1;
            createHeaderTournament.Text = "Create Tournament:";
            // 
            // TournamentLabel
            // 
            TournamentLabel.AutoSize = true;
            TournamentLabel.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            TournamentLabel.ForeColor = SystemColors.MenuHighlight;
            TournamentLabel.Location = new Point(42, 78);
            TournamentLabel.Name = "TournamentLabel";
            TournamentLabel.Size = new Size(298, 46);
            TournamentLabel.TabIndex = 8;
            TournamentLabel.Text = "Tournament Name";
            // 
            // tournamentNameValue
            // 
            tournamentNameValue.BorderStyle = BorderStyle.FixedSingle;
            tournamentNameValue.Location = new Point(50, 125);
            tournamentNameValue.Name = "tournamentNameValue";
            tournamentNameValue.Size = new Size(375, 27);
            tournamentNameValue.TabIndex = 9;
            // 
            // teamOneScoreValue
            // 
            teamOneScoreValue.Dock = DockStyle.Right;
            teamOneScoreValue.Location = new Point(835, 0);
            teamOneScoreValue.Name = "teamOneScoreValue";
            teamOneScoreValue.Size = new Size(104, 27);
            teamOneScoreValue.TabIndex = 11;
            teamOneScoreValue.TextAlign = HorizontalAlignment.Center;
            // 
            // entryFeeLabel
            // 
            entryFeeLabel.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            entryFeeLabel.ForeColor = SystemColors.MenuHighlight;
            entryFeeLabel.Location = new Point(39, 166);
            entryFeeLabel.Name = "entryFeeLabel";
            entryFeeLabel.Size = new Size(206, 46);
            entryFeeLabel.TabIndex = 10;
            entryFeeLabel.Text = "Entry Fee";
            entryFeeLabel.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // entryFeeValue
            // 
            entryFeeValue.BorderStyle = BorderStyle.FixedSingle;
            entryFeeValue.Location = new Point(196, 179);
            entryFeeValue.Name = "entryFeeValue";
            entryFeeValue.Size = new Size(128, 27);
            entryFeeValue.TabIndex = 12;
            entryFeeValue.Text = "0";
            entryFeeValue.TextChanged += entryFeeValue_TextChanged;
            // 
            // selectTeamDropdown
            // 
            selectTeamDropdown.FormattingEnabled = true;
            selectTeamDropdown.Location = new Point(50, 292);
            selectTeamDropdown.Name = "selectTeamDropdown";
            selectTeamDropdown.Size = new Size(375, 28);
            selectTeamDropdown.TabIndex = 14;
            // 
            // selectTeamLabel
            // 
            selectTeamLabel.AutoSize = true;
            selectTeamLabel.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            selectTeamLabel.ForeColor = SystemColors.MenuHighlight;
            selectTeamLabel.Location = new Point(39, 243);
            selectTeamLabel.Name = "selectTeamLabel";
            selectTeamLabel.Size = new Size(198, 46);
            selectTeamLabel.TabIndex = 13;
            selectTeamLabel.Text = "Select Team";
            // 
            // addTeamLink
            // 
            addTeamLink.AutoSize = true;
            addTeamLink.Location = new Point(344, 263);
            addTeamLink.Name = "addTeamLink";
            addTeamLink.Size = new Size(81, 20);
            addTeamLink.TabIndex = 15;
            addTeamLink.TabStop = true;
            addTeamLink.Text = "create new";
            // 
            // addTeamButton
            // 
            addTeamButton.FlatAppearance.BorderColor = Color.Silver;
            addTeamButton.FlatAppearance.MouseDownBackColor = Color.FromArgb(102, 102, 102);
            addTeamButton.FlatAppearance.MouseOverBackColor = Color.FromArgb(142, 142, 142);
            addTeamButton.FlatStyle = FlatStyle.Flat;
            addTeamButton.Font = new Font("Segoe UI Semibold", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            addTeamButton.ForeColor = SystemColors.MenuHighlight;
            addTeamButton.Location = new Point(142, 326);
            addTeamButton.Name = "addTeamButton";
            addTeamButton.Size = new Size(198, 53);
            addTeamButton.TabIndex = 16;
            addTeamButton.Text = "Add Team";
            addTeamButton.UseVisualStyleBackColor = true;
            // 
            // createPrizeButton
            // 
            createPrizeButton.FlatAppearance.BorderColor = Color.Silver;
            createPrizeButton.FlatAppearance.MouseDownBackColor = Color.FromArgb(102, 102, 102);
            createPrizeButton.FlatAppearance.MouseOverBackColor = Color.FromArgb(142, 142, 142);
            createPrizeButton.FlatStyle = FlatStyle.Flat;
            createPrizeButton.Font = new Font("Segoe UI Semibold", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            createPrizeButton.ForeColor = SystemColors.MenuHighlight;
            createPrizeButton.Location = new Point(142, 401);
            createPrizeButton.Name = "createPrizeButton";
            createPrizeButton.Size = new Size(198, 53);
            createPrizeButton.TabIndex = 17;
            createPrizeButton.Text = "Create Prize";
            createPrizeButton.UseVisualStyleBackColor = true;
            // 
            // tournamentPlayersListbox
            // 
            tournamentPlayersListbox.BorderStyle = BorderStyle.FixedSingle;
            tournamentPlayersListbox.FormattingEnabled = true;
            tournamentPlayersListbox.ItemHeight = 20;
            tournamentPlayersListbox.Location = new Point(516, 125);
            tournamentPlayersListbox.Name = "tournamentPlayersListbox";
            tournamentPlayersListbox.Size = new Size(241, 142);
            tournamentPlayersListbox.TabIndex = 18;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = SystemColors.MenuHighlight;
            label1.Location = new Point(493, 78);
            label1.Name = "label1";
            label1.Size = new Size(248, 46);
            label1.TabIndex = 19;
            label1.Text = "Teams / Players";
            label1.Click += label1_Click;
            // 
            // button1
            // 
            button1.FlatAppearance.BorderColor = Color.Silver;
            button1.FlatAppearance.MouseDownBackColor = Color.FromArgb(102, 102, 102);
            button1.FlatAppearance.MouseOverBackColor = Color.FromArgb(142, 142, 142);
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI Semibold", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            button1.ForeColor = SystemColors.MenuHighlight;
            button1.Location = new Point(779, 141);
            button1.Name = "button1";
            button1.Size = new Size(137, 101);
            button1.TabIndex = 20;
            button1.Text = "Delete Selected";
            button1.UseVisualStyleBackColor = true;
            // 
            // prizesDeleteBUtton
            // 
            prizesDeleteBUtton.FlatAppearance.BorderColor = Color.Silver;
            prizesDeleteBUtton.FlatAppearance.MouseDownBackColor = Color.FromArgb(102, 102, 102);
            prizesDeleteBUtton.FlatAppearance.MouseOverBackColor = Color.FromArgb(142, 142, 142);
            prizesDeleteBUtton.FlatStyle = FlatStyle.Flat;
            prizesDeleteBUtton.Font = new Font("Segoe UI Semibold", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            prizesDeleteBUtton.ForeColor = SystemColors.MenuHighlight;
            prizesDeleteBUtton.Location = new Point(779, 365);
            prizesDeleteBUtton.Name = "prizesDeleteBUtton";
            prizesDeleteBUtton.Size = new Size(137, 101);
            prizesDeleteBUtton.TabIndex = 23;
            prizesDeleteBUtton.Text = "Delete Selected";
            prizesDeleteBUtton.UseVisualStyleBackColor = true;
            // 
            // prizesLabel
            // 
            prizesLabel.AutoSize = true;
            prizesLabel.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            prizesLabel.ForeColor = SystemColors.MenuHighlight;
            prizesLabel.Location = new Point(507, 292);
            prizesLabel.Name = "prizesLabel";
            prizesLabel.Size = new Size(106, 46);
            prizesLabel.TabIndex = 22;
            prizesLabel.Text = "Prizes";
            // 
            // prizesListBox
            // 
            prizesListBox.BorderStyle = BorderStyle.FixedSingle;
            prizesListBox.FormattingEnabled = true;
            prizesListBox.ItemHeight = 20;
            prizesListBox.Location = new Point(516, 341);
            prizesListBox.Name = "prizesListBox";
            prizesListBox.Size = new Size(241, 162);
            prizesListBox.TabIndex = 21;
            // 
            // createTournamentButton
            // 
            createTournamentButton.FlatAppearance.BorderColor = Color.Silver;
            createTournamentButton.FlatAppearance.MouseDownBackColor = Color.FromArgb(102, 102, 102);
            createTournamentButton.FlatAppearance.MouseOverBackColor = Color.FromArgb(142, 142, 142);
            createTournamentButton.FlatStyle = FlatStyle.Flat;
            createTournamentButton.Font = new Font("Segoe UI Semibold", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            createTournamentButton.ForeColor = SystemColors.MenuHighlight;
            createTournamentButton.Location = new Point(344, 552);
            createTournamentButton.Name = "createTournamentButton";
            createTournamentButton.Size = new Size(269, 53);
            createTournamentButton.TabIndex = 24;
            createTournamentButton.Text = "Create Tournament";
            createTournamentButton.UseVisualStyleBackColor = true;
            // 
            // CreateTournamentForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(939, 634);
            Controls.Add(createTournamentButton);
            Controls.Add(prizesDeleteBUtton);
            Controls.Add(prizesListBox);
            Controls.Add(button1);
            Controls.Add(label1);
            Controls.Add(tournamentPlayersListbox);
            Controls.Add(createPrizeButton);
            Controls.Add(addTeamButton);
            Controls.Add(addTeamLink);
            Controls.Add(selectTeamDropdown);
            Controls.Add(selectTeamLabel);
            Controls.Add(entryFeeValue);
            Controls.Add(teamOneScoreValue);
            Controls.Add(entryFeeLabel);
            Controls.Add(tournamentNameValue);
            Controls.Add(TournamentLabel);
            Controls.Add(createHeaderTournament);
            Controls.Add(prizesLabel);
            Name = "CreateTournamentForm";
            Text = "CreateTournament";
            Load += CreateTournamentForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label createHeaderTournament;
        private Label TournamentLabel;
        private TextBox tournamentNameValue;
        private TextBox teamOneScoreValue;
        private Label entryFeeLabel;
        private TextBox entryFeeValue;
        private ComboBox selectTeamDropdown;
        private Label selectTeamLabel;
        private LinkLabel addTeamLink;
        private Button addTeamButton;
        private Button createPrizeButton;
        private ListBox tournamentPlayersListbox;
        private Label label1;
        private Button button1;
        private Button prizesDeleteBUtton;
        private Label prizesLabel;
        private ListBox prizesListBox;
        private Button createTournamentButton;
    }
}