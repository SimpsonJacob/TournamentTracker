﻿namespace TrackerUI
{
    partial class CreateTeamForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tournamentNameValue = new TextBox();
            teamNameLabel = new Label();
            createTeamLabel = new Label();
            selectTeamDropdown = new ComboBox();
            selectTeamMemberLabel = new Label();
            addMemberButton = new Button();
            addNewMemberbox = new GroupBox();
            firstNameVal = new TextBox();
            firstNameLabel = new Label();
            lastNameVal = new TextBox();
            lastNameLabel = new Label();
            emailVal = new TextBox();
            emailLabel = new Label();
            cellPhoneVal = new TextBox();
            cellPhoneLabel = new Label();
            createMemberButton = new Button();
            teamMembersBox = new ListBox();
            deleteSelectedMember = new Button();
            createTeamButton = new Button();
            addNewMemberbox.SuspendLayout();
            SuspendLayout();
            // 
            // tournamentNameValue
            // 
            tournamentNameValue.BorderStyle = BorderStyle.FixedSingle;
            tournamentNameValue.Location = new Point(50, 125);
            tournamentNameValue.Name = "tournamentNameValue";
            tournamentNameValue.Size = new Size(447, 43);
            tournamentNameValue.TabIndex = 12;
            // 
            // teamNameLabel
            // 
            teamNameLabel.AutoSize = true;
            teamNameLabel.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            teamNameLabel.ForeColor = SystemColors.MenuHighlight;
            teamNameLabel.Location = new Point(42, 78);
            teamNameLabel.Name = "teamNameLabel";
            teamNameLabel.Size = new Size(197, 46);
            teamNameLabel.TabIndex = 11;
            teamNameLabel.Text = "Team Name";
            // 
            // createTeamLabel
            // 
            createTeamLabel.AutoSize = true;
            createTeamLabel.Font = new Font("Segoe UI Light", 28.2F, FontStyle.Regular, GraphicsUnit.Point);
            createTeamLabel.ForeColor = SystemColors.MenuHighlight;
            createTeamLabel.Location = new Point(12, 9);
            createTeamLabel.Name = "createTeamLabel";
            createTeamLabel.Size = new Size(272, 62);
            createTeamLabel.TabIndex = 10;
            createTeamLabel.Text = "Create Team";
            // 
            // selectTeamDropdown
            // 
            selectTeamDropdown.FormattingEnabled = true;
            selectTeamDropdown.Location = new Point(50, 240);
            selectTeamDropdown.Name = "selectTeamDropdown";
            selectTeamDropdown.Size = new Size(447, 45);
            selectTeamDropdown.TabIndex = 14;
            // 
            // selectTeamMemberLabel
            // 
            selectTeamMemberLabel.AutoSize = true;
            selectTeamMemberLabel.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            selectTeamMemberLabel.ForeColor = SystemColors.MenuHighlight;
            selectTeamMemberLabel.Location = new Point(43, 191);
            selectTeamMemberLabel.Name = "selectTeamMemberLabel";
            selectTeamMemberLabel.Size = new Size(335, 46);
            selectTeamMemberLabel.TabIndex = 13;
            selectTeamMemberLabel.Text = "Select Team Member";
            selectTeamMemberLabel.Click += selectTeamLabel_Click;
            // 
            // addMemberButton
            // 
            addMemberButton.FlatAppearance.BorderColor = Color.Silver;
            addMemberButton.FlatAppearance.MouseDownBackColor = Color.FromArgb(102, 102, 102);
            addMemberButton.FlatAppearance.MouseOverBackColor = Color.FromArgb(142, 142, 142);
            addMemberButton.FlatStyle = FlatStyle.Flat;
            addMemberButton.Font = new Font("Segoe UI Semibold", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            addMemberButton.ForeColor = SystemColors.MenuHighlight;
            addMemberButton.Location = new Point(112, 309);
            addMemberButton.Name = "addMemberButton";
            addMemberButton.Size = new Size(207, 53);
            addMemberButton.TabIndex = 15;
            addMemberButton.Text = "Add Member";
            addMemberButton.UseVisualStyleBackColor = true;
            // 
            // addNewMemberbox
            // 
            addNewMemberbox.Controls.Add(createMemberButton);
            addNewMemberbox.Controls.Add(cellPhoneVal);
            addNewMemberbox.Controls.Add(cellPhoneLabel);
            addNewMemberbox.Controls.Add(emailVal);
            addNewMemberbox.Controls.Add(emailLabel);
            addNewMemberbox.Controls.Add(lastNameVal);
            addNewMemberbox.Controls.Add(lastNameLabel);
            addNewMemberbox.Controls.Add(firstNameVal);
            addNewMemberbox.Controls.Add(firstNameLabel);
            addNewMemberbox.ForeColor = SystemColors.MenuHighlight;
            addNewMemberbox.Location = new Point(50, 400);
            addNewMemberbox.Name = "addNewMemberbox";
            addNewMemberbox.Size = new Size(447, 358);
            addNewMemberbox.TabIndex = 16;
            addNewMemberbox.TabStop = false;
            addNewMemberbox.Text = "Add New Member";
            // 
            // firstNameVal
            // 
            firstNameVal.Location = new Point(234, 42);
            firstNameVal.Name = "firstNameVal";
            firstNameVal.Size = new Size(185, 43);
            firstNameVal.TabIndex = 10;
            // 
            // firstNameLabel
            // 
            firstNameLabel.AutoSize = true;
            firstNameLabel.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            firstNameLabel.ForeColor = SystemColors.MenuHighlight;
            firstNameLabel.Location = new Point(6, 39);
            firstNameLabel.Name = "firstNameLabel";
            firstNameLabel.Size = new Size(181, 46);
            firstNameLabel.TabIndex = 9;
            firstNameLabel.Text = "First Name";
            // 
            // lastNameVal
            // 
            lastNameVal.Location = new Point(234, 103);
            lastNameVal.Name = "lastNameVal";
            lastNameVal.Size = new Size(185, 43);
            lastNameVal.TabIndex = 12;
            // 
            // lastNameLabel
            // 
            lastNameLabel.AutoSize = true;
            lastNameLabel.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            lastNameLabel.ForeColor = SystemColors.MenuHighlight;
            lastNameLabel.Location = new Point(6, 100);
            lastNameLabel.Name = "lastNameLabel";
            lastNameLabel.Size = new Size(177, 46);
            lastNameLabel.TabIndex = 11;
            lastNameLabel.Text = "Last Name";
            // 
            // emailVal
            // 
            emailVal.Location = new Point(234, 161);
            emailVal.Name = "emailVal";
            emailVal.Size = new Size(185, 43);
            emailVal.TabIndex = 14;
            // 
            // emailLabel
            // 
            emailLabel.AutoSize = true;
            emailLabel.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            emailLabel.ForeColor = SystemColors.MenuHighlight;
            emailLabel.Location = new Point(8, 158);
            emailLabel.Name = "emailLabel";
            emailLabel.Size = new Size(99, 46);
            emailLabel.TabIndex = 13;
            emailLabel.Text = "Email";
            // 
            // cellPhoneVal
            // 
            cellPhoneVal.Location = new Point(234, 220);
            cellPhoneVal.Name = "cellPhoneVal";
            cellPhoneVal.Size = new Size(185, 43);
            cellPhoneVal.TabIndex = 16;
            // 
            // cellPhoneLabel
            // 
            cellPhoneLabel.AutoSize = true;
            cellPhoneLabel.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            cellPhoneLabel.ForeColor = SystemColors.MenuHighlight;
            cellPhoneLabel.Location = new Point(6, 217);
            cellPhoneLabel.Name = "cellPhoneLabel";
            cellPhoneLabel.Size = new Size(171, 46);
            cellPhoneLabel.TabIndex = 15;
            cellPhoneLabel.Text = "Cellphone";
            // 
            // createMemberButton
            // 
            createMemberButton.FlatAppearance.BorderColor = Color.Silver;
            createMemberButton.FlatAppearance.MouseDownBackColor = Color.FromArgb(102, 102, 102);
            createMemberButton.FlatAppearance.MouseOverBackColor = Color.FromArgb(142, 142, 142);
            createMemberButton.FlatStyle = FlatStyle.Flat;
            createMemberButton.Font = new Font("Segoe UI Semibold", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            createMemberButton.ForeColor = SystemColors.MenuHighlight;
            createMemberButton.Location = new Point(98, 288);
            createMemberButton.Name = "createMemberButton";
            createMemberButton.Size = new Size(230, 53);
            createMemberButton.TabIndex = 17;
            createMemberButton.Text = "Create Member";
            createMemberButton.UseMnemonic = false;
            createMemberButton.UseVisualStyleBackColor = true;
            // 
            // teamMembersBox
            // 
            teamMembersBox.FormattingEnabled = true;
            teamMembersBox.ItemHeight = 37;
            teamMembersBox.Location = new Point(551, 125);
            teamMembersBox.Name = "teamMembersBox";
            teamMembersBox.Size = new Size(287, 633);
            teamMembersBox.TabIndex = 17;
            // 
            // deleteSelectedMember
            // 
            deleteSelectedMember.FlatAppearance.BorderColor = Color.Silver;
            deleteSelectedMember.FlatAppearance.MouseDownBackColor = Color.FromArgb(102, 102, 102);
            deleteSelectedMember.FlatAppearance.MouseOverBackColor = Color.FromArgb(142, 142, 142);
            deleteSelectedMember.FlatStyle = FlatStyle.Flat;
            deleteSelectedMember.Font = new Font("Segoe UI Semibold", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            deleteSelectedMember.ForeColor = SystemColors.MenuHighlight;
            deleteSelectedMember.Location = new Point(904, 350);
            deleteSelectedMember.Name = "deleteSelectedMember";
            deleteSelectedMember.Size = new Size(137, 101);
            deleteSelectedMember.TabIndex = 21;
            deleteSelectedMember.Text = "Delete Selected";
            deleteSelectedMember.UseVisualStyleBackColor = true;
            // 
            // createTeamButton
            // 
            createTeamButton.FlatAppearance.BorderColor = Color.Silver;
            createTeamButton.FlatAppearance.MouseDownBackColor = Color.FromArgb(102, 102, 102);
            createTeamButton.FlatAppearance.MouseOverBackColor = Color.FromArgb(142, 142, 142);
            createTeamButton.FlatStyle = FlatStyle.Flat;
            createTeamButton.Font = new Font("Segoe UI Semibold", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            createTeamButton.ForeColor = SystemColors.MenuHighlight;
            createTeamButton.Location = new Point(413, 767);
            createTeamButton.Name = "createTeamButton";
            createTeamButton.Size = new Size(230, 53);
            createTeamButton.TabIndex = 18;
            createTeamButton.Text = "Create Team";
            createTeamButton.UseMnemonic = false;
            createTeamButton.UseVisualStyleBackColor = true;
            // 
            // CreateTeamForm
            // 
            AutoScaleDimensions = new SizeF(15F, 37F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1113, 832);
            Controls.Add(createTeamButton);
            Controls.Add(deleteSelectedMember);
            Controls.Add(teamMembersBox);
            Controls.Add(addNewMemberbox);
            Controls.Add(addMemberButton);
            Controls.Add(selectTeamDropdown);
            Controls.Add(selectTeamMemberLabel);
            Controls.Add(tournamentNameValue);
            Controls.Add(teamNameLabel);
            Controls.Add(createTeamLabel);
            Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            Margin = new Padding(6, 6, 6, 6);
            Name = "CreateTeamForm";
            Text = "Create Team";
            addNewMemberbox.ResumeLayout(false);
            addNewMemberbox.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox tournamentNameValue;
        private Label teamNameLabel;
        private Label createTeamLabel;
        private ComboBox selectTeamDropdown;
        private Label selectTeamMemberLabel;
        private Button addMemberButton;
        private GroupBox addNewMemberbox;
        private Button createMemberButton;
        private TextBox cellPhoneVal;
        private Label cellPhoneLabel;
        private TextBox emailVal;
        private Label emailLabel;
        private TextBox lastNameVal;
        private Label lastNameLabel;
        private TextBox firstNameVal;
        private Label firstNameLabel;
        private ListBox teamMembersBox;
        private Button deleteSelectedMember;
        private Button createTeamButton;
    }
}